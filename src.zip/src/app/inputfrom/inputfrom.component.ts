import { Component, OnInit ,Output,EventEmitter, ViewChild, ElementRef} from '@angular/core';
@Component({
  selector: 'app-inputfrom',
  templateUrl: './inputfrom.component.html',
  styleUrls: ['./inputfrom.component.css']
})
export class InputfromComponent implements OnInit {

  //servername = "";
  //servercontent= "";
  @ViewChild('sname') sname :ElementRef
  @Output('sc') servercreated = new EventEmitter<{servername:string, newservercontent:string}>();
 @Output() blueservercreated = new EventEmitter<{servername:string, newservercontent:string}>();
  constructor() { }
  ngOnInit() {

  }
  addserver(sname:HTMLInputElement,scontent:HTMLInputElement)
  {

  console.log(scontent,sname);
    this.servercreated.emit({servername: this.sname.nativeElement.value,newservercontent:scontent.value})
     /*this.serverarr.push({
       type:'sever',
       servername:this.servername,
       servercontent :this.servercontent
     });
     */
  }
  addblueserver(sname:HTMLInputElement,scontent:HTMLInputElement)
  {

    this.blueservercreated.emit({servername: this.sname.nativeElement.value,newservercontent:scontent.value});
/*
this.serverarr.push({
       type:'blue server',
       servername:this.servername,
       servercontent :this.servercontent
     });
     */
  }
  
}
