import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InputfromComponent } from './inputfrom.component';

describe('InputfromComponent', () => {
  let component: InputfromComponent;
  let fixture: ComponentFixture<InputfromComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InputfromComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InputfromComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
