import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'componetconnection';

   serverarr =[];
 // servername ="";
  //servercontent = "";


  onserver(server:{servername:string, newservercontent:string})
  {

     this.serverarr.push({
       type:'sever',
       servername:server.servername,
       servercontent :server.newservercontent
     });
  }
  blueserver(server:{servername:string, newservercontent:string})
  {

  this.serverarr.push({
       type:'blue server',
       servername:server.servername,
       servercontent :server.newservercontent
     });
  }


}
