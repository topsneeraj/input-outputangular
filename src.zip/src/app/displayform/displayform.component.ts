import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-displayform',
  templateUrl: './displayform.component.html',
  styleUrls: ['./displayform.component.css']
})
export class DisplayformComponent implements OnInit {

  constructor() { }

 @Input('el') element :{type:string,servername:string,servercontent:string}


  ngOnInit() {
  }

}
